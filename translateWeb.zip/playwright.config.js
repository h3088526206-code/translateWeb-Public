// @ts-check
const { defineConfig, devices } = require('@playwright/test');

module.exports = defineConfig({
  use: {
    // 使用系统的 Chrome 浏览器
    channel: 'chrome',
    executablePath: 'D:\\Google\\Chrome\\Application\\chrome.exe',
  },
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],
});







