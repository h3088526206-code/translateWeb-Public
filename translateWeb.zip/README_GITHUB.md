# GitHub 上传指南

## 快速方法（推荐）

### 步骤 1: 创建 GitHub 仓库

1. 访问：https://github.com/new
2. 仓库名称：`translateWeb`
3. 选择：Public
4. **不要**勾选 "Initialize with README"
5. 点击 "Create repository"

### 步骤 2: 推送代码

创建仓库后，运行以下命令：

```bash
git push -u origin main
```

如果提示输入密码，使用您的 **Personal Access Token**（不是账户密码）

---

## 自动方法（需要 Token）

如果您有 GitHub Personal Access Token，可以运行：

```bash
powershell -ExecutionPolicy Bypass -File .\auto-push.ps1
```

脚本会自动：
1. 检查仓库是否存在
2. 如果不存在，使用 Token 创建仓库
3. 推送代码到 GitHub

### 获取 Token

1. 访问：https://github.com/settings/tokens
2. 点击 "Generate new token (classic)"
3. 勾选 `repo` 权限
4. 生成并复制 Token

---

## 当前状态

✅ Git 仓库已初始化
✅ 所有文件已提交
✅ 分支已重命名为 main
✅ 远程仓库已配置：`https://github.com/pioneer/translateWeb.git`
⏳ 等待在 GitHub 上创建仓库并推送代码







